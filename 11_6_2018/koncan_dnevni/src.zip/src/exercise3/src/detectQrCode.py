#!/usr/bin/env python
from __future__ import print_function

import roslib
roslib.load_manifest('exercise4')
import sys
import cv2
import numpy as np
import os
import rospy

import tf

import tf2_geometry_msgs
import tf2_ros

import pyzbar.pyzbar as pyzbar

from sensor_msgs.msg import Image
from geometry_msgs.msg import PointStamped, Vector3, Pose
from cv_bridge import CvBridge, CvBridgeError
from visualization_msgs.msg import Marker, MarkerArray
from std_msgs.msg import ColorRGBA
from sound_play.msg import SoundRequest
from sound_play.libsoundplay import SoundClient

class The_Ring:
    def __init__(self):
        rospy.init_node('image_converter', anonymous=True)
        # An object we use for converting images between ROS format and OpenCV format
        self.bridge = CvBridge()

        # A help variable for holding the dimensions of the image
        self.dims = (0, 0, 0)

        # Marker array object used for visualizations
        self.marker_array = MarkerArray()
        self.marker_num = 1

        # Subscribe to the image and/or depth topic
        self.image_sub = rospy.Subscriber("/camera/rgb/image_color", Image, self.image_callback)


        # Publiser for the visualization markers
        self.markers_pub = rospy.Publisher('markers', MarkerArray, queue_size=1000)

        # Object we use for transforming between coordinate frames
        self.tf_buf = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buf)
        print("between fuck 1")

    
    def image_callback(self,data):
    #def image_callback(self,data):
        print('Iam here!')

        sizeX = 640
        sizeY = 480

        try:
            cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
        #cv_image = cv2.imread('Img.jpg')
        except CvBridgeError as e:
            print(e)

        qrDetector(cv_image)


        print("boom")

        #cv2.imshow("Image window",cv_image)
        #cv2.waitKey(0)

        

        rospy.signal_shutdown("lol")
        sys.exit(0)
        print("stop")
        # KODA!!!!!

def qrDetector(cv_image):
    ###########################################
    #### This is relevant for exercise 8
    ###########################################
    print('Ring detected! (hopefully)')

    # Find a QR code in the image
    decodedObjects = pyzbar.decode(cv_image)

    print(decodedObjects)

    

    if len(decodedObjects) == 1:
        dObject = decodedObjects[0]
        print("Found 1 QR code in the image!")
        print("Data: ", dObject.data,'\n')

        x1 = float(dObject.data.split(";")[0].split("_")[0]);
	y1 = float(dObject.data.split(";")[0].split("_")[1]);

	x2 = float(dObject.data.split(";")[3].split("_")[0]);
	y2 = float(dObject.data.split(";")[3].split("_")[1]);

        toFile = y1 + ((y2-y1)/(x2-x1))*(7-x1);

        with open("/home/team_gamma/ROS/src/dataFiles/qrCode.txt", "r+") as the_file:
            the_file.truncate()
            the_file.write(str(toFile))

def main(args):
    print("fuck")
    ring_finder = The_Ring()
    #circle_detected_sound()
    print("after fuck")

    try:
        rospy.spin()
        print("way after fuck")

    except KeyboardInterrupt:
        print("Shutting down")

    #cv2.destroyAllWindows()


if __name__ == '__main__':
    main(sys.argv)
