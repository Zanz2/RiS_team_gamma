import roslib
# roslib.load_manifest('exercise4')
import sys
import rospy
import cv2
import numpy as np
import pytesseract
import pyzbar.pyzbar as pyzbar
from sensor_msgs.msg import Image
from cv_bridge import CvBridge


dictm = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_6X6_250)

# The object that we will pass to the markerDetect function
params =  cv2.aruco.DetectorParameters_create()

#print(params.adaptiveThreshConstant)
#print(params.adaptiveThreshWinSizeMax)
#print(params.adaptiveThreshWinSizeMin)
#print(params.minCornerDistanceRate)
#print(params.adaptiveThreshWinSizeStep)

# To see description of the parameters
# https://docs.opencv.org/3.3.1/d1/dcd/structcv_1_1aruco_1_1DetectorParameters.html

# You can set these parameters to get better marker detections
params.adaptiveThreshConstant = 25
adaptiveThreshWinSizeStep = 2

def qr(cv_image):
    decodedObjects = pyzbar.decode(cv_image)

    # print(decodedObjects)

    if len(decodedObjects) == 1:
        dObject = decodedObjects[0]
        print("Found 1 QR code in the image!")

        coords = dObject.data.split(";")
        x1, y1 = coords[0].split("_")
        x2, y2 = coords[2].split("_")
        k = (float(y2) - float(y1)) / (float(x2) - float(x1))
        print(k)

        # Visualize the detected QR code in the image
        points = dObject.polygon
        if len(points) > 4:
            hull = cv2.convexHull(np.array([point for point in points], dtype=np.float32))
            hull = list(map(tuple, np.squeeze(hull)))
        else:
            hull = points;

        ## Number of points in the convex hull
        n = len(hull)

        ## Draw the convext hull
        for j in range(0, n):
            cv2.line(cv_image, hull[j], hull[(j + 1) % n], (0, 255, 0), 2)

        # cv2.imwrite("images/output_qr.bmp", img_out)

    elif len(decodedObjects) == 0:
        print("No QR code in the image")
    else:
        print("Found more than 1 QR code")

def digits(cv_image):
    corners, ids, rejected_corners = cv2.aruco.detectMarkers(cv_image, dictm, parameters=params)

    # Increase proportionally if you want a larger image
    image_size = (351, 248, 3)
    marker_side = 50

    img_out = np.zeros(image_size, np.uint8)
    out_pts = np.array([[marker_side / 2, img_out.shape[0] - marker_side / 2],
                        [img_out.shape[1] - marker_side / 2, img_out.shape[0] - marker_side / 2],
                        [marker_side / 2, marker_side / 2],
                        [img_out.shape[1] - marker_side / 2, marker_side / 2]])

    src_points = np.zeros((4, 2))
    cens_mars = np.zeros((4, 2))

    if not ids is None:
        if len(ids) == 4:
            print('4 Markers detected')

            for idx in ids:
                # Calculate the center point of all markers
                cors = np.squeeze(corners[idx[0] - 1])
                cen_mar = np.mean(cors, axis=0)
                cens_mars[idx[0] - 1] = cen_mar
                cen_point = np.mean(cens_mars, axis=0)

            for coords in cens_mars:
                #  Map the correct source points
                if coords[0] < cen_point[0] and coords[1] < cen_point[1]:
                    src_points[2] = coords
                elif coords[0] < cen_point[0] and coords[1] > cen_point[1]:
                    src_points[0] = coords
                elif coords[0] > cen_point[0] and coords[1] < cen_point[1]:
                    src_points[3] = coords
                else:
                    src_points[1] = coords

            h, status = cv2.findHomography(src_points, out_pts)
            img_out = cv2.warpPerspective(cv_image, h, (img_out.shape[1], img_out.shape[0]))

            ################################################
            #### Extraction of digits starts here
            ################################################

            # Cut out everything but the numbers
            img_out = img_out[125:221, 50:195, :]

            # Convert the image to grayscale
            img_out = cv2.cvtColor(img_out, cv2.COLOR_BGR2GRAY)

            # Option 1 - use ordinairy threshold the image to get a black and white image
            # ret,img_out = cv2.threshold(img_out,100,255,0)

            # Option 1 - use adaptive thresholding
            img_out = cv2.adaptiveThreshold(img_out, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 5)

            # Use Otsu's thresholding
            # ret,img_out = cv2.threshold(img_out,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)

            # Pass some options to tesseract
            config = '--psm 13 outputbase nobatch digits'

            # Visualize the image we are passing to Tesseract
            # cv2.imshow('Warped image',img_out)
            cv2.imwrite("images/output_dig.bmp", img_out);
            # cv2.waitKey(1)

            # Extract text from image
            text = pytesseract.image_to_string(img_out, config=config)

            # Check and extract data from text
            # print('Extracted>>', text)

            # Remove any whitespaces from the left and right
            text = text.strip()

            #             # If the extracted text is of the right length
            if len(text) == 2:
                x = int(text[0])
                y = int(text[1])
                # print('The extracted datapoints are x=%d, y=%d' % (x, y))
            else:
                print('The extracted text has is of length %d. Aborting processing' % len(text))
            return

        else:
            print('The number of markers is not ok:', len(ids))
    else:
        print('No markers found')

def plot(cv_image):
    corners, ids, rejected_corners = cv2.aruco.detectMarkers(cv_image,dictm,parameters=params)

    # Increase proportionally if you want a larger image
    image_size=(351*2,248*2,3)
    marker_side=50*2

    img_out = np.zeros(image_size, np.uint8)
    out_pts = np.array([[marker_side/2,img_out.shape[0]-marker_side/2],
                        [img_out.shape[1]-marker_side/2,img_out.shape[0]-marker_side/2],
                        [marker_side/2,marker_side/2],
                        [img_out.shape[1]-marker_side/2,marker_side/2]])

    src_points = np.zeros((4,2))
    cens_mars = np.zeros((4,2))

    if not ids is None:
        if len(ids)==4:
            print('4 Markers detected')

            for idx in ids:
                # Calculate the center point of all markers
                cors = np.squeeze(corners[idx[0]-1])
                cen_mar = np.mean(cors,axis=0)
                cens_mars[idx[0]-1]=cen_mar
                cen_point = np.mean(cens_mars,axis=0)

            for coords in cens_mars:
                #  Map the correct source points
                if coords[0]<cen_point[0] and coords[1]<cen_point[1]:
                    src_points[2]=coords
                elif coords[0]<cen_point[0] and coords[1]>cen_point[1]:
                    src_points[0]=coords
                elif coords[0]>cen_point[0] and coords[1]<cen_point[1]:
                    src_points[3]=coords
                else:
                    src_points[1]=coords

            h, status = cv2.findHomography(src_points, out_pts)
            img_out = cv2.warpPerspective(cv_image, h, (img_out.shape[1],img_out.shape[0]))

            ################################################
            #### Extraction of plot starts here
            ################################################

            # Cut out everything but the numbers
            img_out = img_out[125*2:221*2,50*2:195*2,:]

            # Convert the image to grayscale
            img_out = cv2.cvtColor(img_out, cv2.COLOR_BGR2GRAY)

            # Option 1 - use ordinairy threshold the image to get a black and white image
            #ret,img_out = cv2.threshold(img_out,100,255,0)

            # Option 1 - use adaptive thresholding
            img_out = cv2.adaptiveThreshold(img_out,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,17,3)

            # Use Otsu's thresholding
            #ret,img_out = cv2.threshold(img_out,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)

            height, width = img_out.shape
            w1 = width // 4
            w2 = width - w1
            y1 = 0
            y2 = 0
            det1 = False
            det2 = False

            for i in range(height):
                if(det1 and img_out[i][w1] == 0 and y1 != 0):
                    det1 = False
                    break
                elif(img_out[i][w1] == 0):
                    det1 = True
                elif(det1 and img_out[i][w1] == 255):
                    y1 += 1
                if(det2 and img_out[i][w2] == 0 and y2 != 0):
                    det2 = False
                    break
                elif(img_out[i][w2] == 0):
                    det2 = True
                elif(det2 and img_out[i][w2] == 255):
                    y2 += 1

            print(y1, y2)
            k = (y2-y1)/2
            print(k)
            # we get y and x when we read the numbers
            # n = y - k*x
            #cv2.imwrite( "images/output_plot.bmp", img_out );
            return
        else:
            print('The number of markers is not ok:',len(ids))
    else:
         print('No markers found')
