#!/usr/bin/env python
from __future__ import print_function

import roslib
roslib.load_manifest('exercise4')
import sys
import cv2
import numpy as np
import os
import rospy
import pytesseract
import tf

import tf2_geometry_msgs
import tf2_ros

import pyzbar.pyzbar as pyzbar

from sensor_msgs.msg import Image
from geometry_msgs.msg import PointStamped, Vector3, Pose
from cv_bridge import CvBridge, CvBridgeError
from visualization_msgs.msg import Marker, MarkerArray
from std_msgs.msg import ColorRGBA
from sound_play.msg import SoundRequest
from sound_play.libsoundplay import SoundClient

dictm = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_6X6_250)
params =  cv2.aruco.DetectorParameters_create()

params.adaptiveThreshConstant = 25
adaptiveThreshWinSizeStep = 2


class The_Ring:
    def __init__(self):
        rospy.init_node('image_converter', anonymous=True)
        # An object we use for converting images between ROS format and OpenCV format
        self.bridge = CvBridge()

        # A help variable for holding the dimensions of the image
        self.dims = (0, 0, 0)

        # Marker array object used for visualizations
        self.marker_array = MarkerArray()
        self.marker_num = 1

        # Subscribe to the image and/or depth topic
        self.image_sub = rospy.Subscriber("/camera/rgb/image_color", Image, self.image_callback)


        # Publiser for the visualization markers
        self.markers_pub = rospy.Publisher('markers', MarkerArray, queue_size=1000)

        # Object we use for transforming between coordinate frames
        self.tf_buf = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buf)
        print("between fuck 1")

    
    def image_callback(self,data):
    #def image_callback(self,data):
        print('Iam here!')

        sizeX = 640
        sizeY = 480

        try:
            cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
        #cv_image = cv2.imread('Img.jpg')
        except CvBridgeError as e:
            print(e)

        plot(cv_image)


        print("boom")

        #cv2.imshow("Image window",cv_image)
        #cv2.waitKey(0)

        

        rospy.signal_shutdown("lol")
        sys.exit(0)
        print("stop")
        # KODA!!!!!


def plot(cv_image):
    global dictm
    corners, ids, rejected_corners = cv2.aruco.detectMarkers(cv_image,dictm,parameters=params)

    # Increase proportionally if you want a larger image
    image_size=(351*2,248*2,3)
    marker_side=50*2

    img_out = np.zeros(image_size, np.uint8)
    out_pts = np.array([[marker_side/2,img_out.shape[0]-marker_side/2],
                        [img_out.shape[1]-marker_side/2,img_out.shape[0]-marker_side/2],
                        [marker_side/2,marker_side/2],
                        [img_out.shape[1]-marker_side/2,marker_side/2]])

    src_points = np.zeros((4,2))
    cens_mars = np.zeros((4,2))

    if not ids is None:
        if len(ids)==4:
            print('4 Markers detected')

            for idx in ids:
                # Calculate the center point of all markers
                cors = np.squeeze(corners[idx[0]-1])
                cen_mar = np.mean(cors,axis=0)
                cens_mars[idx[0]-1]=cen_mar
                cen_point = np.mean(cens_mars,axis=0)

            for coords in cens_mars:
                #  Map the correct source points
                if coords[0]<cen_point[0] and coords[1]<cen_point[1]:
                    src_points[2]=coords
                elif coords[0]<cen_point[0] and coords[1]>cen_point[1]:
                    src_points[0]=coords
                elif coords[0]>cen_point[0] and coords[1]<cen_point[1]:
                    src_points[3]=coords
                else:
                    src_points[1]=coords

            h, status = cv2.findHomography(src_points, out_pts)
            img_out = cv2.warpPerspective(cv_image, h, (img_out.shape[1],img_out.shape[0]))

            ################################################
            #### Extraction of plot starts here
            ################################################

            # Cut out everything but the numbers
            img_out = img_out[125*2:221*2,50*2:195*2,:]

            # Convert the image to grayscale
            img_out = cv2.cvtColor(img_out, cv2.COLOR_BGR2GRAY)

            # Option 1 - use ordinairy threshold the image to get a black and white image
            #ret,img_out = cv2.threshold(img_out,100,255,0)

            # Option 1 - use adaptive thresholding
            img_out = cv2.adaptiveThreshold(img_out,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,17,3)

            # Use Otsu's thresholding
            #ret,img_out = cv2.threshold(img_out,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)

            height, width = img_out.shape
            w1 = width // 4
            w2 = width - w1
            y1 = 0
            y2 = 0
            det1 = False
            det2 = False

            for i in range(height):
                if(det1 and img_out[i][w1] == 0 and y1 != 0):
                    det1 = False
                    break
                elif(img_out[i][w1] == 0):
                    det1 = True
                elif(det1 and img_out[i][w1] == 255):
                    y1 += 1
                if(det2 and img_out[i][w2] == 0 and y2 != 0):
                    det2 = False
                    break
                elif(img_out[i][w2] == 0):
                    det2 = True
                elif(det2 and img_out[i][w2] == 255):
                    y2 += 1

            print(y1, y2)
            k = (y2-y1)/2
            print(k)

            with open("/home/team_gamma/ROS/src/dataFiles/logData.txt", "r+") as the_file:
                    the_file.write("krog graph " + str(k));

            with open("/home/team_gamma/ROS/src/dataFiles/graph.txt", "r+") as the_file:
	        the_file.truncate()
	        the_file.write(str(k))

            # we get y and x when we read the numbers
            # n = y - k*x
            #cv2.imwrite( "images/output_plot.bmp", img_out );
            return
        else:
            print('The number of markers is not ok:',len(ids))
    else:
         print('No markers found')



def main(args):
    print("fuck")
    ring_finder = The_Ring()
    #circle_detected_sound()
    print("after fuck")

    try:
        rospy.spin()
        print("way after fuck")

    except KeyboardInterrupt:
        print("Shutting down")

    #cv2.destroyAllWindows()


if __name__ == '__main__':
    main(sys.argv)
